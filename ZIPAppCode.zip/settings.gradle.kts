rootProject.name = "BusyaTimer"
include(":app")